/**
 * Component Loader for Bridger Western Wiki
 * Dynamically loads navigation and footer components
 */

class ComponentLoader {
    constructor() {
        this.components = {
            'nav': '/components/nav.html',
            'footer': '/components/footer.html'
        };
    }

    /**
     * Load a component into a container
     * @param {string} componentName - 'nav' or 'footer'
     * @param {string} containerId - HTML element id to load into
     */
    async loadComponent(componentName, containerId) {
        const url = this.components[componentName];
        if (!url) {
            console.error(`Component ${componentName} not defined`);
            return;
        }

        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`Failed to load ${componentName}: ${response.status}`);
            }
            
            const html = await response.text();
            const container = document.getElementById(containerId);
            
            if (container) {
                container.innerHTML = html;
                
                // Re-execute any script tags in the loaded component
                container.querySelectorAll('script').forEach(oldScript => {
                    const newScript = document.createElement('script');
                    Array.from(oldScript.attributes).forEach(attr => {
                        newScript.setAttribute(attr.name, attr.value);
                    });
                    newScript.textContent = oldScript.textContent;
                    oldScript.parentNode.replaceChild(newScript, oldScript);
                });

                // After loading nav, set active state based on current URL
                if (componentName === 'nav') {
                    this.setActiveNavItem();
                }
            } else {
                console.error(`Container ${containerId} not found`);
            }
        } catch (error) {
            console.error(`Error loading ${componentName}:`, error);
            
            // Fallback: Show error message
            const container = document.getElementById(containerId);
            if (container) {
                container.innerHTML = `<div style="color: #666; padding: 20px; text-align: center;">
                    Navigation component could not be loaded.
                </div>`;
            }
        }
    }

    /**
     * Set active state on navigation items based on current URL
     */
    setActiveNavItem() {
        const currentPath = window.location.pathname;
        
        // Remove all active classes first
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        
        // Find matching nav item
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            
            if (href === '/') {
                // Home page - only active on root
                if (currentPath === '/' || currentPath === '/index.html') {
                    link.classList.add('active');
                }
            } else if (href && currentPath.startsWith(href)) {
                // Section pages - active when in that section
                link.classList.add('active');
            }
        });
    }

    /**
     * Initialize and load all components
     */
    async init() {
        // Load navigation if container exists
        if (document.getElementById('nav-container')) {
            await this.loadComponent('nav', 'nav-container');
            this.setupMobileNav();
        }
        
        // Load footer if container exists
        if (document.getElementById('footer-container')) {
            await this.loadComponent('footer', 'footer-container');
        }
    }

    /**
     * Setup mobile navigation functionality
     */
    setupMobileNav() {
        // Wait a bit for the nav to be fully loaded
        setTimeout(() => {
            const toggle = document.querySelector('.nav-toggle');
            const nav = document.querySelector('.main-nav');
            
            if (toggle && nav) {
                toggle.addEventListener('click', () => nav.classList.toggle('open'));
            }
            
            // Dropdown on mobile tap
            document.querySelectorAll('.nav-link').forEach(link => {
                link.addEventListener('click', e => {
                    if (window.innerWidth <= 768) {
                        e.preventDefault();
                        link.closest('.nav-item').classList.toggle('active');
                    }
                });
            });
        }, 100);
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    const loader = new ComponentLoader();
    loader.init();

    // ── Global TOC (On This Page) ──────────────────────────────
    // Runs on all pages. If a #page-toc container exists, populate it.
    // Otherwise, if the page has enough H2s, create a floating TOC FAB.
    (function initTOC() {
        // Find content area: prefer .page-sidebar-main, fallback to .page-toc-main, then <main>
        var contentArea = document.querySelector('.page-sidebar-main') 
            || document.querySelector('.page-toc-main')
            || document.querySelector('main');
        if (!contentArea) return;

        // Collect H2s with section-title class first, then all H2s (skip first/last)
        var h2s = Array.from(contentArea.querySelectorAll('h2.section-title'));
        if (h2s.length === 0) {
            var all = Array.from(contentArea.querySelectorAll('h2'));
            h2s = all.length > 2 ? all.slice(1, all.length - 1) : all;
        }
        if (h2s.length < 2) return; // not enough sections to warrant a TOC

        // Assign IDs
        h2s.forEach(function(h, i) {
            if (!h.id) h.id = 'sec-' + i;
        });

        function buildLinks(container) {
            if (!container) return;
            h2s.forEach(function(h) {
                var a = document.createElement('a');
                a.href = '#' + h.id;
                var text = h.textContent.trim().replace(/^[^a-zA-Z0-9]+/, '').trim();
                a.textContent = text || h.textContent.trim();
                container.appendChild(a);
            });
        }

        // Populate existing #page-toc and #page-toc-mobile if present
        buildLinks(document.getElementById('page-toc'));
        buildLinks(document.getElementById('page-toc-mobile'));

        // Scroll highlight via IntersectionObserver
        var allTocContainers = [
            document.getElementById('page-toc'),
            document.getElementById('page-toc-mobile')
        ].filter(Boolean);

        if (allTocContainers.length > 0 && 'IntersectionObserver' in window) {
            var observer = new IntersectionObserver(function(entries) {
                entries.forEach(function(e) {
                    allTocContainers.forEach(function(container) {
                        var link = container.querySelector('a[href="#' + e.target.id + '"]');
                        if (link) link.classList.toggle('toc-active', e.isIntersecting);
                    });
                });
            }, { rootMargin: '-5% 0px -80% 0px' });
            h2s.forEach(function(h) { observer.observe(h); });
        }
    })();
});

// Export for manual usage
window.ComponentLoader = ComponentLoader;

/**
 * Global User Intent Collection System
 * 针对停留时间短（< 30秒）的用户，在鼠标离开视口时弹出意图收集弹窗
 * 整个会话只弹一次（sessionStorage 记录）
 */
class UserIntentCollector {
    constructor() {
        this.SESSION_KEY = 'bw_popup_shown';
        this.SESSION_START_KEY = 'bw_session_start';

        // 本次会话已弹过，直接跳过
        if (sessionStorage.getItem(this.SESSION_KEY)) return;

        // 记录会话开始时间（第一次进入网站时设置，之后不覆盖）
        if (!sessionStorage.getItem(this.SESSION_START_KEY)) {
            sessionStorage.setItem(this.SESSION_START_KEY, Date.now().toString());
        }

        this.init();
    }

    init() {
        // 桌面端：鼠标离开视口顶部时触发
        document.addEventListener('mouseleave', (e) => {
            if (e.clientY <= 0 && this.shouldShowPopup()) {
                this.showExitIntentPopup('mouse_leave');
            }
        });
    }

    shouldShowPopup() {
        // 已弹过（sessionStorage 双重保险）
        if (sessionStorage.getItem(this.SESSION_KEY)) return false;
        // 全站累计停留时间 < 30 秒才弹
        const sessionStart = parseInt(sessionStorage.getItem(this.SESSION_START_KEY) || Date.now());
        const totalTimeSpent = (Date.now() - sessionStart) / 1000;
        return totalTimeSpent < 30;
    }

    showExitIntentPopup(trigger = 'exit_intent') {
        // 标记本次会话已弹过
        sessionStorage.setItem(this.SESSION_KEY, '1');

        const sessionStart = parseInt(sessionStorage.getItem(this.SESSION_START_KEY) || Date.now());
        const timeSpent = Math.round((Date.now() - sessionStart) / 1000);

        // Create popup HTML
        const popup = document.createElement('div');
        popup.className = 'exit-intent-popup';
        popup.innerHTML = `
            <div class="exit-popup-overlay"></div>
            <div class="exit-popup-content">
                <button class="exit-popup-close" onclick="this.closest('.exit-intent-popup').remove(); document.body.style.overflow='';">✕</button>
                
                <div class="exit-popup-header">
                    <h3>🤔 Wait! Did you find what you were looking for?</h3>
                    <p>Help us improve by telling us what you needed:</p>
                </div>

                <div class="exit-popup-options">
                    <button onclick="userIntentCollector.submitIntent('found_what_needed', this)" class="intent-option success">
                        ✅ Yes, I found what I needed
                    </button>
                    <button onclick="userIntentCollector.submitIntent('content_missing', this)" class="intent-option missing">
                        📝 The content I need isn't here
                    </button>
                </div>

                <div class="exit-popup-help" id="help-section" style="display: none;">
                    <h4>What are you looking for?</h4>
                    <textarea id="user-need-text" placeholder="e.g., 'How to get The World Stand', 'Best card builds for beginners'..." maxlength="500"></textarea>
                    <button onclick="userIntentCollector.submitCustomNeed()" class="btn">Submit</button>
                </div>

                <div class="exit-popup-footer">
                    <p>Your feedback helps us create better content 🙏</p>
                </div>
            </div>
        `;

        document.body.appendChild(popup);
        document.body.style.overflow = 'hidden';

        // 记录弹窗展示事件（带停留时间）
        if (typeof gtag === 'function') {
            gtag('event', 'exit_intent_popup_shown', {
                'event_category': 'user_retention',
                'event_label': trigger,
                'value': timeSpent,
                'time_on_page': timeSpent,
                'page_url': window.location.pathname
            });
        }

        // 30 秒后自动关闭
        setTimeout(() => {
            if (document.querySelector('.exit-intent-popup')) {
                popup.remove();
                document.body.style.overflow = '';
            }
        }, 30000);
    }

    submitIntent(intent, button) {
        // Track the intent
        if (typeof gtag === 'function') {
            gtag('event', 'exit_intent_response', {
                'event_category': 'user_feedback',
                'event_label': intent,
                'value': 1,
                'page_url': window.location.pathname
            });
        }

        if (intent === 'content_missing') {
            // 展示文本输入框
            document.getElementById('help-section').style.display = 'block';
            button.style.background = '#17a2b8';
            button.style.color = 'white';
        } else {
            // Close popup after brief delay
            setTimeout(() => {
                document.querySelector('.exit-intent-popup').remove();
                document.body.style.overflow = '';
            }, 1500);
        }

        // Disable all buttons
        document.querySelectorAll('.intent-option').forEach(btn => {
            if (btn !== button) {
                btn.disabled = true;
                btn.style.opacity = '0.5';
            }
        });
    }

    submitCustomNeed() {
        const text = document.getElementById('user-need-text').value.trim();
        if (text.length < 10) {
            alert('Please provide more details (at least 10 characters)');
            return;
        }

        // Track custom need
        if (typeof gtag === 'function') {
            gtag('event', 'exit_intent_custom_need', {
                'event_category': 'user_feedback',
                'event_label': 'custom_need_submitted',
                'value': 1,
                'custom_need_text': text,
                'page_url': window.location.pathname
            });
        }

        // Show success and close
        document.getElementById('help-section').innerHTML = '<p style="color: #28a745; text-align: center;">✅ Thank you! We\'ll use this to improve our content.</p>';
        
        setTimeout(() => {
            document.querySelector('.exit-intent-popup').remove();
            document.body.style.overflow = '';
        }, 2000);
    }

}

// Initialize user intent collector on all pages
let userIntentCollector;
document.addEventListener('DOMContentLoaded', function() {
    userIntentCollector = new UserIntentCollector();
});

// Load AI chat widget (temporarily disabled)
// (function() {
//     var script = document.createElement('script');
//     script.src = '/js/chat.js';
//     script.defer = true;
//     document.head.appendChild(script);
// })();